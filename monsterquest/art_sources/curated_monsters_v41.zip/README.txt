30 original image-first sprites from the prior generated 10-family design sheet.
64x64 transparent PNG. <=15 opaque colors + 1 transparency.
BEAST, DRAGON, KNIGHT, SPIRIT, GOLEM, EYE, BAT, ARCHER,
SORCERER, SLIME x 3 stages each.
Source for MonsterQuest 4.1 CuratedMonsterArt.kt.
All sprites face RIGHT; monsters appearing as enemies are mirrored LEFT.
These are reduced/edited from the design concept, not hand-pixelled originals.
